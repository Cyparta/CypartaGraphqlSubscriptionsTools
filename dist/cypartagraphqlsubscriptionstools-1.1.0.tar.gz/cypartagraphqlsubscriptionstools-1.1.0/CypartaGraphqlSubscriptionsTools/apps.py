from django.apps import AppConfig


class GrapheneSubscriptionsConfig(AppConfig):
    name = "CypartaGraphqlSubscriptionsTools"
